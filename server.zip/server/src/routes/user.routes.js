import express from 'express';
import { protect } from '../middleware/auth.middleware.js';
import { getDashboardService } from '../services/user.service.js';

const router = express.Router();

// 📊 DASHBOARD
router.get('/dashboard', protect, async (req, res) => {
  try {
    const data = await getDashboardService(req.user.userId);

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
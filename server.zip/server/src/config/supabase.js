import { createClient } from '@supabase/supabase-js';


export const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

console.log("USING KEY:", process.env.SUPABASE_SERVICE_KEY?.slice(0, 20));
import { supabase } from '../config/supabase.js';

export const getDashboardService = async (userId) => {
  // 👤 USER
  const { data: user } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single();

  // 📋 SCHEMES
  const { data: schemes } = await supabase
    .from('user_schemes')
    .select(`
      *,
      schemes (*)
    `)
    .eq('user_id', userId);

  // 🧩 MILESTONES
  const { data: milestones } = await supabase
    .from('user_milestones')
    .select(`
      *,
      milestones (*)
    `)
    .eq('user_id', userId);

  // 📂 DOCUMENTS
  const { data: documents } = await supabase
    .from('documents')
    .select('*')
    .eq('user_id', userId);

  // 🔔 NOTIFICATIONS
  const { data: notifications } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  return {
    user,
    schemes,
    milestones,
    documents,
    notifications,
  };
};

const { data } = await supabase.rpc('auth.jwt');
console.log("JWT ROLE:", data);
import { supabase } from '../config/supabase.js';
import bcrypt from 'bcryptjs';
import { generateToken } from '../utils/jwt.js';

export const sendOTPService = async (phone) => {
  const otp = Math.floor(100000 + Math.random() * 900000).toString();

  const { data: existing } = await supabase
    .from('otp_sessions')
    .select('*')
    .eq('mobile', phone)
    .maybeSingle();

  if (existing) {
    await supabase
      .from('otp_sessions')
      .update({
        otp_code: otp,
        verified: false,
        expires_at: new Date(Date.now() + 5 * 60 * 1000),
      })
      .eq('mobile', phone);
  } else {
    await supabase
      .from('otp_sessions')
      .insert({
        mobile: phone,
        otp_code: otp,
        verified: false,
        expires_at: new Date(Date.now() + 5 * 60 * 1000),
      });
  }

  return otp;
};

export const verifyOTPService = async (phone, otp) => {
  const { data, error } = await supabase
    .from('otp_sessions')
    .select('*')
    .eq('mobile', phone)
    .maybeSingle();

  if (error) throw new Error(error.message);
  console.log("OTP DB:", data);
  if (!data) throw new Error('OTP not found');

  if (data.otp_code !== otp) throw new Error('Invalid OTP');

  if (new Date(data.expires_at) < new Date()) {
    throw new Error('OTP expired');
  }

  await supabase
    .from('otp_sessions')
    .update({ verified: true })
    .eq('mobile', phone);

  const { data: user } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .single();

  if (!user) {
    return { user: null, token: null };
  }

  const token = generateToken({
    userId: user.id,
    role: 'citizen',
  });

  return { user, token };
};

export const adminLoginService = async (email, password) => {
  const { data: admin } = await supabase
    .from('admins')
    .select('*')
    .eq('email', email)
    .single();

  if (!admin) throw new Error('Admin not found');

  const isMatch = await bcrypt.compare(password, admin.password_hash);

  if (!isMatch) throw new Error('Invalid credentials');

  const token = generateToken({
    adminId: admin.id,
    role: admin.role,
  });

  return { admin, token };
};
export const registerUserService = async (phone, data) => {
  const { data: existing } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .maybeSingle();

  if (existing) {
    throw new Error('User already exists');
  }

  const { data: user, error } = await supabase
    .from('users')
    .insert({
      phone,
      full_name: data.full_name,
      gender: data.gender,
      date_of_birth: data.date_of_birth,

      state: data.state,
      district: data.district,
      ward: data.ward,
      village: data.village,
      pincode: data.pincode,

      category: data.category,
      occupation: data.occupation,
      annual_income: data.annual_income,
      land_acres: data.land_acres,

      aadhaar_number: data.aadhaar_number,
      voter_id: data.voter_id,

      profile_complete: true,
    })
    .select()
    .single();

  if (error) throw new Error(error.message);

  const token = generateToken({
    userId: user.id,
    role: 'citizen',
  });

  return { user, token };
};